$dbhost = "localhost";//this should be fine for all but NJIT, which uses "sql1.njit.edu" or "sql2.njit.edu" or "sql3.njit.edu"
$dbuser = "ucid";//your ucid since we follow this pattern
$dbpass = "";//database password generated or chosen per respective steps
$dbdatabase = "ucid";//your ucid since we follow this pattern
?>
